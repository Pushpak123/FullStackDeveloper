package com.example.demo.model;

import org.springframework.stereotype.Component;

@Component(value = "google.co.in")
public class Google implements ISearch {

	@Override
	public void serchResult() {
		System.out.println("Google");		
	}

}
