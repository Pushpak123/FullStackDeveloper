package com.example.demo.model;

import org.springframework.stereotype.Component;

@Component
public class Payment {

}
