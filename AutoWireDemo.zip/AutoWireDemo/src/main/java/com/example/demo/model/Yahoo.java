package com.example.demo.model;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component
@Primary	//if more than beans need to pick one hence given by default
public class Yahoo implements ISearch {

	@Override
	public void serchResult() {
		System.out.println("Yahoo");		
		
	}

}
