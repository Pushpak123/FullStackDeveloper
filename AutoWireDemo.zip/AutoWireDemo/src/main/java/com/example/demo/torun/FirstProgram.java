package com.example.demo.torun;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.example.demo.model.SBI;

@Component
public class FirstProgram implements CommandLineRunner {
	@Autowired
	SBI sbi;
	
	@Autowired
	SBI sbi_mumbai;

	@Override
	public void run(String... args) throws Exception {
		System.out.println("FirstProgram executed");
		System.out.println(sbi.hashCode());
		System.out.println(sbi.getBranchName());
		
		System.out.println(sbi_mumbai.hashCode());
		sbi_mumbai.setBranchName("Mumbai");
		System.out.println(sbi_mumbai.getBranchName());
	}
}
