package com.example.demo.torun;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.example.demo.model.ISearch;

@Component
public class SecondProgram implements CommandLineRunner {
	@Autowired
	//@Qualifier("google")	//search by class name
	//@Qualifier("google.co.in")	//search by value
	//@Qualifier("yahoo")	//search by class name
	ISearch search;
	
	@Override
	public void run(String... args) throws Exception {
		System.out.println("SecondProgram executed");	
		search.serchResult();
	}

}
