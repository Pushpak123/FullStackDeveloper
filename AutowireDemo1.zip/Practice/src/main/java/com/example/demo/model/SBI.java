package com.example.demo.model;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class SBI implements ITransaction {
	@Value("Pune")
	private String branchName;

	@Override
	public void payment() {
		System.out.println("SBI Payment executed...");
		
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

}
