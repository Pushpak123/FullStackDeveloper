package com.example.demo.torun;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.example.demo.model.SBI;

@Component
public class FirstSpringDemo implements CommandLineRunner {
	@Autowired
	SBI sbi;
	
	@Override
	public void run(String... args) throws Exception {
		System.out.println("FirstSpringDemo executed...");
		System.out.println(sbi.hashCode());
		sbi.payment();
		//sbi.setBranchName("Pune");
		System.out.println("BranchName: " + sbi.getBranchName());
	}

}
