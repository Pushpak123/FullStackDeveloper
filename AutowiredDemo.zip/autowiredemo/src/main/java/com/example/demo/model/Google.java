package com.example.demo.model;

import org.springframework.stereotype.Component;

@Component(value="google.co.in")
public class Google implements ISearch {

	public void searchResult() {
		System.out.println("Google ");
	}
}
