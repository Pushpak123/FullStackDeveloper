package com.example.demo.model;

import org.springframework.stereotype.Component;

@Component
public interface ISearch {
	void searchResult();
}


