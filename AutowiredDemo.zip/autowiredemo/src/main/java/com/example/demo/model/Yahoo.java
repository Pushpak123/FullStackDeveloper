package com.example.demo.model;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component
@Primary
public class Yahoo implements ISearch {

	@Override
	public void searchResult() {
		System.out.println("Yahoo");		
	}

}
