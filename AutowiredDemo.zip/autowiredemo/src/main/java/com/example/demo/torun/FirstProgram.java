package com.example.demo.torun;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.example.demo.model.SBI;

@Component
public class FirstProgram implements CommandLineRunner {

	@Autowired
	SBI sbi;

	@Autowired
	SBI sbi_mumbi;

	@Override
	public void run(String... args) throws Exception {

		System.out.println("FirstProgram executed");

		System.out.println(sbi.hashCode());

		System.out.println(sbi.getBranchName());

		System.out.println(sbi_mumbi.hashCode());
		
		sbi_mumbi.setBranchName("mumbai");

		System.out.println(sbi_mumbi.getBranchName());
		
		System.out.println(sbi_mumbi.getPayment().hashCode());

	}

}
