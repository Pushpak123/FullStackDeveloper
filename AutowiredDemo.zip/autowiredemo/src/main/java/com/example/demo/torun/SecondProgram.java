package com.example.demo.torun;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.example.demo.model.Google;
import com.example.demo.model.ISearch;
import com.example.demo.model.SBI;

@Component
public class SecondProgram implements CommandLineRunner {

	@Autowired()
	//@Qualifier("google.co.in")
	ISearch search;

	
	@Override
	public void run(String... args) throws Exception {

		System.out.println("SecondProgram executed");

		search.searchResult();
		 
	}

}
