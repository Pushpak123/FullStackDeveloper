package com.example.demo;

import org.springframework.boot.autoconfigure.cache.CacheProperties.EhCache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.concurrent.ConcurrentMapCacheManager;
import org.springframework.cache.ehcache.EhCacheCacheManager;
import org.springframework.cache.ehcache.EhCacheManagerFactoryBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;

@Configuration
@EnableCaching
public class CachConfig {
	@Bean
	public CacheManager myCacheManager() {
		//return new ConcurrentMapCacheManager();
		
		return new EhCacheCacheManager(getEhcase().getObject());
	}
	
	@Bean
	public EhCacheManagerFactoryBean getEhcase() {
		EhCacheManagerFactoryBean b = new EhCacheManagerFactoryBean();
		b.setConfigLocation(new ClassPathResource("ehcache.xml"));
		b.setShared(true);
		return b;
	}
}