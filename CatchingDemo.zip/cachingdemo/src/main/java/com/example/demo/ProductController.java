package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ProductController {
	
	@Autowired
	private ProductService pService;
	
	@RequestMapping("/product/list")
	public ModelAndView list() {
		
		ModelAndView m = new ModelAndView("productlist");
		
		m.addObject("list", pService.getAllProduct());
		
		return m;
		
	}
	
	
	@RequestMapping("/product/create")
	public ModelAndView create() {
	
		ModelAndView m = new ModelAndView("productcreate");
			
		return m;
		
	}
	
	@RequestMapping(value= "/product/create",method=RequestMethod.POST)
	public ModelAndView create(ProductEntity p) {
	
		ModelAndView m = new ModelAndView("productcreate");
		
		pService.createProduct(p);
		
		m.setViewName("redirect:/product/list");
			
			
		return m;
		
	}

}
