package com.example.demo;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

@Service
public class ProductService {
	
	@Autowired
	private ProductRepository productRepo;
	
	//https://www.ehcache.org/documentation/2.8/configuration/configuration.html
	@Cacheable (value="getall" )
	public List<ProductEntity> getAllProduct() {
		System.out.println("Fetch data from DB");
		return productRepo.findAll();
		
	}
	
	public List<ProductEntity> getByName(String name) {
		
		return productRepo.findByProductName(name);
		
	}
	
	public ProductEntity createProduct(ProductEntity p) {
		
		return productRepo.save(p);
				
	}

	public void deleteProduct(int id) {
		productRepo.deleteById(id);
		
	}

	public ProductEntity updateProduct(int id, ProductEntity p) {
		Optional<ProductEntity> oldProduct =  productRepo.findById(id);
		if(oldProduct.isPresent())
		{
			p.setProductId(id);			
			return productRepo.save(p);	
		}
		
		return null;
	}
	
	

}
