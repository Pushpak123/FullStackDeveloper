package Factory;

public class FactoryDemoProgram {
	public static void main(String[] args) {
		System.out.println("Factory Demo Program");
		ITransaction trans = TransactionFactory.getInstance("SBI");
		
		trans = TransactionFactory.getInstace(SBITransaction.class);
		System.out.println(trans.hashCode());
		
		trans = TransactionFactory.getInstace(PaytmTransaction.class);
		System.out.println(trans.hashCode());
		
		trans = TransactionFactory.getInstace(SBITransaction.class);
		System.out.println(trans.hashCode());
		
		trans = TransactionFactory.getInstace(PaytmTransaction.class);
		System.out.println(trans.hashCode());
		trans.startPayment();
		
	}
}
