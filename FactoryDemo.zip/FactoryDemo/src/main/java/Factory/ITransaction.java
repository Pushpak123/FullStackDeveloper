package Factory;

public interface ITransaction {	
	boolean startPayment();
}
