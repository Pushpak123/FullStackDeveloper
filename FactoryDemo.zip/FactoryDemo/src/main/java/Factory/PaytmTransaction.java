package Factory;

import org.springframework.stereotype.Component;

@Component
public class PaytmTransaction implements ITransaction {

	@Override
	public boolean startPayment() {
		System.out.println("Paytm Transaction Details");
		return true;
	}

}
