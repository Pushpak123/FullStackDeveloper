package Factory;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

//@Scope(scopeName = "singletone")	// by default single object for all (default Lazy = false)
//@Scope(scopeName = "prototype")	// Different object for all (default Lazy = true)
//@Lazy(value = false)
@Component
public class SBITransaction implements ITransaction {

	public SBITransaction() {
		System.out.println("SBITransaction constructor");
	}
	
	@Override
	public boolean startPayment() {
		System.out.println("SBI Transaction Details");
		
		return true;
	}

}
