package Factory;

import java.util.HashMap;
import java.util.Map;

//https://codepen.io/TainCode/pen/KOqxep

public class TransactionFactory {
	static Map<String, ITransaction> tran = new HashMap<>();
	static Map<Class, ITransaction> tranMap = new HashMap<>();
	
	public static ITransaction getInstance(String methodType) {
		
		if("PayTM".equalsIgnoreCase(methodType) && tran.get(methodType) == null)
			tran.put(methodType, new PaytmTransaction());			
		else if("SBI".equalsIgnoreCase(methodType) && tran.get(methodType) == null)
			tran.put(methodType, new SBITransaction());			
		return tran.get(methodType);
	}

		
	public static ITransaction getInstace(Class type) {
		if (type == PaytmTransaction.class  && tranMap.get(type) == null)
			tranMap.put(type, new PaytmTransaction()); 
		else if(tranMap.get(type) == null)
			tranMap.put(type, new SBITransaction());
		return tranMap.get(type);
	}
}
