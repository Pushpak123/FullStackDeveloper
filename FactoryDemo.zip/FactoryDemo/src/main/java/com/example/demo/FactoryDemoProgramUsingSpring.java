package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;

import Factory.SBITransaction;

@EnableAutoConfiguration
@ComponentScan({"Factory"})
public class FactoryDemoProgramUsingSpring {
	public static void main(String[] args) {
		System.out.println("Factory Demo Program Using Spring");
		
		/*AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();		
		context.register(SBITransaction.class);		
		context.refresh();		
		SBITransaction sbi = context.getBean(SBITransaction.class);
		sbi.startPayment();
		System.out.println(sbi.hashCode());
		sbi = context.getBean(SBITransaction.class);
		sbi.startPayment();
		System.out.println(sbi.hashCode());*/
		
		ConfigurableApplicationContext context = SpringApplication.run(FactoryDemoProgramUsingSpring.class, args);
		
		/*SBITransaction sbi = (SBITransaction) context.getBean(SBITransaction.class);
		System.out.println(sbi.hashCode());*/
		
		// Removed above two lines by using autowired annotation
		ToTestAutowired toTest = new ToTestAutowired();
		try {
			toTest.run();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
		System.out.println("EOP");		
	}
}
