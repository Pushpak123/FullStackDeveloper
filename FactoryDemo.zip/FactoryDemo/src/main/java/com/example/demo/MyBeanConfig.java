package com.example.demo;

import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Scope;

import Factory.SBITransaction;

@Configurable
public class MyBeanConfig {
	@Bean
	@Scope(scopeName = "prototype")
	public SBITransaction getSBITransaction() {
		return new SBITransaction();
	}
	
	@Bean(name = "singletoneobject")
	@Primary
	@Scope(scopeName = "singleton")
	public SBITransaction getSBITransactionSingletone() {
		return new SBITransaction();
	}
	
}
