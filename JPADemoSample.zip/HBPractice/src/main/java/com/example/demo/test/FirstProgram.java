package com.example.demo.test;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.example.demo.entity.Employee;
import com.example.demo.repository.EmployeeRepository;

@Component
public class FirstProgram implements CommandLineRunner{
	@Autowired
	EmployeeRepository empRepo;
	
	@Override
	public void run(String... args) throws Exception {
		System.out.println("My First Hibernet Program");
		
		//empRepo.save(new Employee("Amol", 50000));
		//empRepo.save(new Employee("Saurabh",45000));
		//System.out.println("Record inserted...");
		
		List<Employee> empList = empRepo.findAll();
		System.out.println("Employee Details");
		for(Employee e : empList) {
			System.out.println(e.getEmpId() + " " + e.getEmpName() + " " + e.getSalary());
		}
		
		System.out.println("Get all employee details by name");
		List<Employee> empListByName = empRepo.findByEmpName("Amol");
		for(Employee e : empListByName) {
			System.out.println(e.getEmpId() + " " + e.getEmpName() + " " + e.getSalary());
		}
		
	
	}

}
