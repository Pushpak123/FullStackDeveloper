package com.example.demo.dto;

import java.io.Serializable;

import org.springframework.stereotype.Component;

@Component
public class EmployeeProjection implements Serializable {
	private String empName;
	private int salary;
	
	public EmployeeProjection() {
		
	}
		
	public EmployeeProjection(String empName, int salary) {
		this.setEmpName(empName);
		this.setSalary(salary);
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}
	
	
}
