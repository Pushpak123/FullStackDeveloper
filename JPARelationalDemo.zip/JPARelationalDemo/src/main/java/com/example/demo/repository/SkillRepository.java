package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;

import com.example.demo.dto.EmployeeSkillDTO;
import com.example.demo.entity.Skill;

@Component
public interface SkillRepository extends JpaRepository<Skill, Integer> 
{
	@Query("FROM Skill S join fetch S.employee e WHERE e.empName = :empName")
	List<Skill> getAllSkillByEmpName(@Param("empName") String empName);
	
	@Query("select new com.example.demo.dto.EmployeeSkillDTO(e.empName, s.skillName) "
			+ "FROM Skill s, Employee e ")
	List<EmployeeSkillDTO> getEmployeeDetails();
} 
