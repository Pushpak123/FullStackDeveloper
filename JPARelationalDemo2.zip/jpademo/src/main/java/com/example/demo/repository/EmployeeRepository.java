package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;

import com.example.demo.dto.EmployeeProjection;
import com.example.demo.entity.Employee;

@Component
public interface EmployeeRepository extends JpaRepository<Employee, Integer>
{


	List<Employee> findByEmployeeName(String employeeName);
	
	@Query("from Employee where employeeName=:x")
	List<Employee> JpaEmployeeName(
			@Param("x") String employeeName
			);

	@Query(nativeQuery=true,
		value="select * from Employee "
					+ "where employee_Name=:employeeName")
	List<Employee> SQLEmployeeName(
			@Param("employeeName") String employeeName
			);
	
	@Query("select "
			+ "new com.example.demo.dto.EmployeeProjection(e.employeeName,e.salary)"
			+ " from Employee e")
	List<EmployeeProjection> JpaByProjection();
	
	
	
	
	
	
	
}
