package com.example.demo.torun;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.example.demo.dto.EmployeeProjection;
import com.example.demo.entity.Employee;
import com.example.demo.repository.EmployeeRepository;

@Component
public class FirstProgram implements CommandLineRunner {
	
	@Autowired
	EmployeeRepository repo;

	@Override
	public void run(String... args) throws Exception {

		System.out.println("JPA Demo");
		
		System.out.println(repo.findAll().size());
		
		List<EmployeeProjection> list = repo.JpaByProjection();
		
		for (EmployeeProjection ep : list) {
			System.out.println(ep.getEmployeeName());
			System.out.println(ep.getSalary());
		}

	}

}
