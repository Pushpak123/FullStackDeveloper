package com.example.demo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.example.demo.entity.Course;
import com.example.demo.entity.Student;
import com.example.demo.repository.CourseRepository;
import com.example.demo.repository.StudentRepository;

@Component
public class ManyToManyDemo implements CommandLineRunner {
	@Autowired
	StudentRepository studRepository;
@Autowired
CourseRepository crepo;
	@Override
	public void run(String... args) throws Exception {
		System.out.println("ManyToManyDemo executed...");
		
		Course courseOne = new Course();
		courseOne.setCourseName("Java");
		
		Course courseTwo = new Course();
		courseTwo.setCourseName("Angular");
		
		Student studentOne = new Student();
		studentOne.setStudentName("Amol");
		
		Student studentTwo = new Student();
		studentTwo.setStudentName("Akshay");
		
		Student studentThree = new Student();
		studentThree.setStudentName("Ritesh");
		
		courseOne.students = new ArrayList<Student>();
		courseOne.students.add(studentOne);
		courseOne.students.add(studentTwo);
		courseOne.students.add(studentThree);
		
		courseTwo.students = new ArrayList<Student>();
		courseTwo.students.add(studentOne);
		
		List<Course> courseList = new ArrayList<Course>();
		courseList.add(courseOne);
		courseList.add(courseTwo);
		crepo.saveAll(courseList);
		studRepository.saveAll(courseList);
	}

}
