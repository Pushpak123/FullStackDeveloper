package com.example.demo.dto;

import java.io.Serializable;

import org.springframework.stereotype.Component;


public class EmployeeSkillDTO implements Serializable {
	
	private String empName;
	private String skillName;
	
	public EmployeeSkillDTO(String empName, String skillName) {
		this.empName = empName;
		this.skillName = skillName;
	}

	public String getEmpName() {
		return empName;
	}

	public String getSkillName() {
		return skillName;
	}

	
	
}
