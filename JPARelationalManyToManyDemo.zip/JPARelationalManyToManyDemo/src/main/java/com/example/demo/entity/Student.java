package com.example.demo.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

public class Student {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public int studentId;

	public String studentName;

	
	@ManyToMany(cascade = CascadeType.ALL, mappedBy = "Students")
	List<Course> courses;
	
	public Student() {
		
	}
	
	public Student(String studentName, List<Course> courses) {
		this.studentName = studentName;
		this.courses = courses;
	}

	public int getStudentId() {
		return studentId;
	}

	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}
	

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public List<Course> getCourses() {
		return courses;
	}

	public void setCourses(List<Course> courses) {
		this.courses = courses;
	}
}
