package com.example.demo.torun;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.example.demo.dto.EmployeeProjection;
import com.example.demo.dto.EmployeeSkillDTO;
import com.example.demo.entity.Employee;
import com.example.demo.entity.Skill;
import com.example.demo.repository.EmployeeRepository;
import com.example.demo.repository.SkillRepository;

@Component
public class FirstProgram implements CommandLineRunner {
	@Autowired
	EmployeeRepository empRepo;
	
	@Autowired
	SkillRepository skillRepo;
	
	@Override
	public void run(String... args) throws Exception {
		System.out.println("FirstProgram executed...");		
		
		Employee employee = new Employee("Amol", 50000);
		//empRepo.save(employee);			
		System.out.println("Record Inserted in Employee ...");
		
		Skill skill1 = new Skill("JAVA", employee);
		Skill skill2 = new Skill("JSP", employee);
		
		List<Skill> skillList = new ArrayList<Skill>();
		skillList.add(skill1);
		skillList.add(skill2);
		skillRepo.saveAll(skillList);
		
		System.out.println("Record Inserted in Skill ...");
		
		System.out.println(empRepo.findAll().size());
		System.out.println(skillRepo.findAll().size());
		
		
		System.out.println("Fetch All Skill Data");
		List<Skill> skill = skillRepo.findAll();
		for(Skill s : skill) {
			System.out.println(s.getSkillName() + "  " + s.getEmployee().getEmpName());
		}
		
		System.out.println("Fetch all data by id");
		Optional<Skill> skillListById = skillRepo.findById(1);
		System.out.println(skillListById.get().getSkillName() + "  " + skillListById.get().getEmployee().getEmpName());
		
		
		System.out.println("Fetch All Skill Data by employee name");
		List<Skill> skillList1 = skillRepo.getAllSkillByEmpName("Amol");
		for(Skill s:skillList1) {
			System.out.println(s.getSkillId() + "  " + s.getSkillName() + "  "+ s.getEmployee().getEmpName());
		}
		
		System.out.println("Employee Repository");
		List<Employee> skillList2 = empRepo.getAllSkillByEmpName("Amol");
		for(Employee e:skillList2) {
			System.out.println(e.getEmpName());
			for(Skill s: e.getSkillList())
				System.out.println(s.getSkillId() + "  " + s.getSkillName());
		}
		
		System.out.println("Employee Repository using SQL");
		List<Employee> skillList3 = empRepo.getAllSkillByEmpName("Amol");
		for(Employee e:skillList3) {
			System.out.println(e.getEmpName());
			for(Skill s: e.getSkillList())
				System.out.println(s.getSkillId() + "  " + s.getSkillName());
		}
		
		
		System.out.println("*** Get all Employee Details ***");
		List<EmployeeSkillDTO> empSkillList = skillRepo.getEmployeeDetails();
		for(EmployeeSkillDTO es:empSkillList) {
			System.out.println("Employee & Skill Name is " + es.getEmpName() + "  " + es.getSkillName());
		}
		
		
		/*List<Employee> empList = repository.findByEmpName("Amol");
		for(Employee e:empList)
			System.out.println("Employee Details: " + e.getEmpName() + " having salary is " + e.getSalary());
		
		System.out.println(repository.findAll().size());
		
		List<Employee> empSalList = repository.findBySalaryGreaterThan(40000);
		
		for(Employee e:empSalList)
			System.out.println("Employee name having salary  grater than 40000: " + e.getEmpName());
		
		List<Employee> empJpaList = repository.jpaEmpName("Atul");
		for(Employee e:empJpaList)
			System.out.println("Employee Details using JPA style: " + e.getEmpName() + " having salary is " + e.getSalary());
		
		
		List<EmployeeProjection> empJpaProjList = repository.JpaByProjection();
		for(EmployeeProjection e:empJpaProjList)
			System.out.println("Employee Details using JPA projection style: " + e.getEmpName() + " having salary is " + e.getSalary());
		*/
		System.out.println("EOP");
	}

}
