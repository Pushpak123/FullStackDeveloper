package com.example.demo.serviceDAO;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.User;

import java.util.List;

import javax.transaction.Transactional;

@Repository
@Transactional
public interface UserService extends JpaRepository<User, Integer> {
	@Query("from User")
	List<User> myMethod();
	
	List<User> findByUserId(int id);
}
