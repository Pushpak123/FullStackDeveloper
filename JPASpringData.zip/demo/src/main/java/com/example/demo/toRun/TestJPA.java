package com.example.demo.toRun;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.example.demo.entity.User;
import com.example.demo.serviceDAO.UserService;

@Component
public class TestJPA implements CommandLineRunner {

	@Autowired
	UserService userSerive;
	
	@Override
	public void run(String... args) throws Exception {
		User user = new User();
		user.setUserName("Pushpak Barhate");
		userSerive.save(user);
		
		List<User> userList  =  userSerive.findAll();
		for(User u:userList) {
			System.out.println("User Name is " + u.getUserName());
		}	
		
		List<User> userList1 =  userSerive.findByUserId(1);
		for(User u:userList1) {
			System.out.println("User Name by using mthod is " + u.getUserName());
		}
	}
}
