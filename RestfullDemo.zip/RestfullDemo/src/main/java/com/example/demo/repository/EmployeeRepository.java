package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;

import com.example.demo.dto.EmployeeProjection;
import com.example.demo.entity.Employee;

@Component
public interface EmployeeRepository extends JpaRepository<Employee, Integer> {

	List<Employee> findByEmpName(String empName);
	
	@Query("from Employee where empName = :empName")
	List<Employee> jpaEmpName(@Param("empName") String empName);
	
	@Query(nativeQuery = true, value = "select * from Employee where empName = :empName")
	List<Employee> SQLEmpName(@Param("empName") String empName);

	List<Employee> findBySalaryGreaterThan(int salary);
	
	@Query("select new com.example.demo.dto.EmployeeProjection(e.empName, e.salary) from Employee e")
	List<EmployeeProjection> JpaByProjection();
	

}
