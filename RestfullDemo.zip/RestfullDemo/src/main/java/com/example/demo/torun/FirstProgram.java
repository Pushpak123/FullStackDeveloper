package com.example.demo.torun;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.example.demo.dto.EmployeeProjection;
import com.example.demo.entity.Employee;
import com.example.demo.repository.EmployeeRepository;

@Component
public class FirstProgram implements CommandLineRunner {
	@Autowired
	EmployeeRepository repository;
	
	@Override
	public void run(String... args) throws Exception {
		System.out.println("FirstProgram executed...");		
		
		repository.save(new Employee("Amol", 50000));
		repository.save(new Employee("Atul", 30000));
		
		System.out.println("Record Inserted...");
		
		List<Employee> empList = repository.findByEmpName("Amol");
		for(Employee e:empList)
			System.out.println("Employee Details: " + e.getEmpName() + " having salary is " + e.getSalary());
		
		System.out.println(repository.findAll().size());
		
		List<Employee> empSalList = repository.findBySalaryGreaterThan(40000);
		
		for(Employee e:empSalList)
			System.out.println("Employee name having salary  grater than 40000: " + e.getEmpName());
		
		List<Employee> empJpaList = repository.jpaEmpName("Atul");
		for(Employee e:empJpaList)
			System.out.println("Employee Details using JPA style: " + e.getEmpName() + " having salary is " + e.getSalary());
		
		
		List<EmployeeProjection> empJpaProjList = repository.JpaByProjection();
		for(EmployeeProjection e:empJpaProjList)
			System.out.println("Employee Details using JPA projection style: " + e.getEmpName() + " having salary is " + e.getSalary());
		
		System.out.println("EOP");
	}

}
