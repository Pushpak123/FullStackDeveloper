package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class ToTestUser implements CommandLineRunner {

	@Autowired
	UserRepository userRepository;
	@Override
	public void run(String... args) throws Exception {
		UserTable user = new UserTable();
		user.setUserName("AmolP");
		user.setPwd("1234");
		
		userRepository.save(user);
		
		
		UserTable found = userRepository.findByUserNameAndPwd("AmolP","1234");
		System.out.println(found.getUserId() + " " + found.getUserName()+ " " + found.getPwd());
		
	}

}
