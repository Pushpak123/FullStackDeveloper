package com.example.demo;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class FirstPage {
	@RequestMapping("/")
	public String home() {
		System.out.println("My Home Page");
		return "home";
	}
	
	@RequestMapping("/login")
	public String login() {
		System.out.println("My Login Page");
		return "login";
	}
	
	@RequestMapping("/logout")
	public String logout() {
		System.out.println("My logout Page");
		return "logout";
	}
	
	@RequestMapping("/logout1")
	public String logout1() {
		System.out.println("My logout1 Page");
		return "logout1";
	}
	
	@RequestMapping("/error1")
	public String error1() {
		System.out.println("My error1 Page");
		return "error1";
	}
	
	@RequestMapping("/about")
	public String about() {
		System.out.println("My about Page");
		return "about";
	}
	
	@RequestMapping("/payment")
	public String payment() {
		System.out.println("My payment Page");
		return "payment";
	}
	
	@RequestMapping("/adminpage")
	public String adminpage() {
		System.out.println("My adminpage Page");
		return "adminpage";
	}
}
