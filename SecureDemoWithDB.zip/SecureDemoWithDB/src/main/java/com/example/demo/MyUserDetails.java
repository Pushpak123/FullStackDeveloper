package com.example.demo;

import java.util.Collection;
import java.util.Collections;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

public class MyUserDetails implements UserDetails {
	
	UserTable userTable;
	
	public MyUserDetails(UserTable userTable) {
		this.userTable = userTable;
	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {		
		return Collections.singleton(new SimpleGrantedAuthority("user"));
	}

	@Override
	public String getPassword() {
		System.out.println("Pwd is " + userTable.getPwd());
		return userTable.getPwd();
	}

	@Override
	public String getUsername() {
		System.out.println("Pwd is " + userTable.getUserName());
		return userTable.getUserName();
	}

	@Override
	public boolean isAccountNonExpired() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isAccountNonLocked() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isEnabled() {
		// TODO Auto-generated method stub
		return true;
	}

}
