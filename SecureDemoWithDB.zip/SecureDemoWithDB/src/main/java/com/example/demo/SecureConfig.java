package com.example.demo;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;

@Configuration
@EnableWebSecurity
public class SecureConfig extends WebSecurityConfigurerAdapter {
	
	@Autowired
	UserDetailsService userDetailsService; 

	/*@Autowired
	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		
		  auth.inMemoryAuthentication() .withUser("Amol") .password("{noop}123") //
		  noop is used to consider this pwd as plain text not in encrypted format
		  .roles("Admin");
		 
		
		
		  DaoAuthenticationProvider dbProvider = new DaoAuthenticationProvider();
		  dbProvider.setUserDetailsService(userDetailsService);
		  dbProvider.setPasswordEncoder(NoOpPasswordEncoder.getInstance());
		  
		  auth.authenticationProvider(dbProvider);
		 
	}*/

	@Bean
	public AuthenticationProvider getProvider() {
		DaoAuthenticationProvider dbProvider = new DaoAuthenticationProvider();
		dbProvider.setUserDetailsService(userDetailsService);
		dbProvider.setPasswordEncoder(NoOpPasswordEncoder.getInstance());
		
		return dbProvider;
	}
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		//disable default login logout flow
		http.csrf().disable();
		
		http.formLogin()
			.loginPage("/login")	// my login page url
			.usernameParameter("username")	// take username from my own login page
			.passwordParameter("pwd")	// take pwd from my own login page
			.defaultSuccessUrl("/");	// after successful login redirect to default page
		
		http.formLogin().failureUrl("/error1");	// redirect login failure
		http.logout()
			.logoutUrl("/logout")
			.logoutSuccessUrl("/logout1");
		
		
		http.exceptionHandling().accessDeniedPage("/login");
		
		http.authorizeRequests()
			.antMatchers("/").permitAll()	// allow
			.antMatchers("/error1").permitAll()
			.antMatchers("/login").permitAll()	// allow
			.antMatchers("/logout").permitAll()	// allow
			.antMatchers("/logout1").permitAll()	// allow
			.antMatchers("/about").permitAll()	// allow
			.antMatchers("/payment").denyAll()	// required login
			.antMatchers("/adminpage").access("hasRole('admin')")	// required role
			.anyRequest().authenticated();	// all other pages required login
			
			
		
		
		
	}
	
	

}
