package com.example.demo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;

@Component
public interface UserRepository extends JpaRepository<UserTable, Integer>  {

	//@Query("FROM UserTable u WHERE u.userName = :userName and u.pwd = :pwd")
	//UserTable findByUserNameAndPwd(@Param("empName")String userName, @Param("empName") String pwd);

	@Query
	UserTable findByUserNameAndPwd(String userName, String pwd);

	@Query
	UserTable findByUserName(String userName);
}
