package com.example.demo;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

public class SecurityWebInit extends AbstractSecurityWebApplicationInitializer {

}
