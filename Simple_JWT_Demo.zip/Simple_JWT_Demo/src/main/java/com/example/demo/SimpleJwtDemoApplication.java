package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimpleJwtDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimpleJwtDemoApplication.class, args);
	}

}
