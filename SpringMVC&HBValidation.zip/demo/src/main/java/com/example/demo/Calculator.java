package com.example.demo;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class Calculator {

	@RequestMapping("/cal")
	public String showForm() {
		System.out.println("showForm");	
		return "calculator";
	}
	
	@RequestMapping(value="/cal",method= RequestMethod.POST)
	public ModelAndView processForm(int n1,int n2) {
		System.out.println("processForm");
		System.out.println(n1);
		System.out.println(n2);
		
		ModelAndView mv = new ModelAndView(); 
		mv.setViewName("calculator");
		
		mv.addObject("result", n1 + n2);
		
		return mv;
		
		//in jsp ${result}
	}
	
}

