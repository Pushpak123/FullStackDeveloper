package com.example.demo;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class Counter {

	@RequestMapping("/counter")
	public ModelAndView showForm() {

		ModelAndView mv = new ModelAndView();
		mv.setViewName("counter");
		mv.addObject("n1", 1);

		return mv;
	}

	// JSP : <input type="text" name="n1" value=${n1} />

	@RequestMapping(value = "/counter", method = RequestMethod.POST)
	public ModelAndView processForm(int n1, String operation) {

		ModelAndView mv = new ModelAndView();
		mv.setViewName("counter");
		if (operation.equalsIgnoreCase("Incress"))
			mv.addObject("n1", n1 + 1);
		else
			mv.addObject("n1", n1 -	 1);

		return mv;

	}

}
