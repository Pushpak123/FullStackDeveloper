package com.example.demo;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class FirstPage {


	@RequestMapping("/")
	public String home() {
		System.out.println("home hi");
		return "hi";
	}

	//http://localhost:8080/about/me
	@RequestMapping("/about/me")
	@GetMapping()
	public String about() {
		System.out.println("home about");
		//WEB-INF/jsp/about.jsp
		return "about";
	}
	
	
	
}
