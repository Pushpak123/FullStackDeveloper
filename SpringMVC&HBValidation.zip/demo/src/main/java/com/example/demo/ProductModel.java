package com.example.demo;

import javax.validation.constraints.*;

import org.springframework.format.annotation.NumberFormat;
import org.springframework.format.annotation.NumberFormat.Style;

public class ProductModel {
	
	@NotBlank(message="message.product.productname.notblank")
	@NotNull(message="plz enter product name - null")
	private String productname;
	
	@NotNull(message="plz enter price - null")
	@Min(value=0,message="plz enter price grator than zero.")
	@Max(value=999,message="plz enter price less than 999.")
	private Integer price;

	public String getProductname() {
		return productname;
	}

	public void setProductname(String productname) {
		this.productname = productname;
	}

	public Integer getPrice() {
		return price;
	}

	public void setPrice(Integer price) {
		this.price = price;
	}
	
	
	
}
