package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class ToRunCategory implements CommandLineRunner {

	
	@Autowired
	CategoryRepository cRepo;
	
	
	@Override
	public void run(String... args) throws Exception {
		
		Category c = new Category("Book");
		
		//Save category
		cRepo.save(c);
		
		//print all category
		List<Category> list =  cRepo.findAll();
		
		for (Category category : list) {
			System.out.println(category.getCategoryId());
			System.out.println(category.getCategoryName());
		}
		
		
	}

	
}
