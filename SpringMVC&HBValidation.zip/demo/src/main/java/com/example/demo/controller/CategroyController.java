package com.example.demo.controller;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.Category;
import com.example.demo.CategoryRepository;

@Controller
public class CategroyController {

	
	@RequestMapping("/category")
	public ModelAndView showCreateForm(){
		
		ModelAndView m = new ModelAndView();
		m.setViewName("category");
		
		return m;
		
		
	}
	
	@Autowired
	CategoryRepository cRepo;
	
	@RequestMapping(value="/category",method=RequestMethod.POST)
	public ModelAndView processCreateForm(String categoryName){

		ModelAndView m = new ModelAndView();
		m.setViewName("category");
		
		Category c = new Category();
		c.setCategoryName(categoryName);
		
		Category saveResult =  cRepo.save(c);
		
		System.out.println(saveResult.getCategoryId());
		
		m.addObject("categoryId", saveResult.getCategoryId());
		
		//HTML <div>${categoryId}</div>
		
		
		
		return m;
		
		
	}
	
	
	@RequestMapping("/categorylist")
	public ModelAndView categorylist(){
		
		ModelAndView m = new ModelAndView();
		m.setViewName("categorylist");
		
		//print all category
		List<Category> list =  cRepo.findAll();
		
		for (Category category : list) {
			System.out.println(category.getCategoryId());
			System.out.println(category.getCategoryName());
		}
		
		m.addObject("list",list);
		
		return m;
		
		
	}
	
	
	@RequestMapping("/categorydetail")
	public ModelAndView getCategoryDetail(int categoryId){
		ModelAndView m=new ModelAndView();
		Optional<Category> c =  cRepo.findById(categoryId);
				
				m.addObject("c",c);
				
				return m;
				
				
				
				
	}
	 
	
	
	
	
	
	
	
	
	
	
	
}
