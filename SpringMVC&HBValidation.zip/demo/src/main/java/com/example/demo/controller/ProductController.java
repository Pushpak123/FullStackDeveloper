package com.example.demo.controller;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.ProductModel;

@Controller
public class ProductController {

	@RequestMapping("/createproduct")
	public ModelAndView createProduct() {
		
		ModelAndView m = new ModelAndView();
		
		m.setViewName("createproduct");
		
		return m;
		
	}
	
	
	/*@RequestMapping(value="/createproduct",method=RequestMethod.POST)
	public ModelAndView c(String productname,int price ) {
		
		System.out.println(productname);
		System.out.println(price);
		
		ModelAndView m = new ModelAndView();
		
		m.setViewName("createproduct");
		
		return m;
		
	}*/
	
	
	
	
	
	@RequestMapping(value="/createproduct",method=RequestMethod.POST)
	public ModelAndView createproduct(
			@Valid ProductModel productModel, BindingResult result 
			) {
		
		ModelAndView m = new ModelAndView();
		
		//HTML
		//result.getFieldError("price").getDefaultMessage();
			
		
		if(result.hasErrors()==true) {
			result.getAllErrors().stream()
			.forEach(x->System.out.println(x.getDefaultMessage()));
		}
		else {
			System.out.println(productModel.getProductname());
			System.out.println(productModel.getPrice());	
		}
		
		m.addObject("result", result);
		m.setViewName("createproduct");
		
		return m;
		
	}
	
}
