package com.example.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;

import com.example.demo.Entity.User;

@Component
public interface UserRepository extends JpaRepository<User, Integer> {
		//by jpa
		@Query
		User findByUserNameAndPassword(String userName, String password);
		@Query
		User findByUserName(String userName);

}
