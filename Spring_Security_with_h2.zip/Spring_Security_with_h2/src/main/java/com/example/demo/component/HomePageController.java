package com.example.demo.component;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HomePageController {
	@RequestMapping("/")
	public ModelAndView showFrom(){
		String Name=SecurityContextHolder.getContext().getAuthentication().getName();
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("user",Name);
		modelAndView.setViewName("home");
		return modelAndView;
		
	}
	@RequestMapping("/login")
	public ModelAndView showLoginFrom(){
		System.out.println("login");
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("login");
		return modelAndView;
		
	}
	
	@RequestMapping("/logout")
	public ModelAndView showLogoutFrom(){
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("logout");
		return modelAndView;
		
	}
	
	@RequestMapping("/errors")
	public ModelAndView showErrorFrom(){
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("error");
		return modelAndView;
		
	}
}
