package com.example.demo.toRun;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.example.demo.Entity.User;
import com.example.demo.Repository.UserRepository;

@Component
public class AppContext implements CommandLineRunner{
 
	@Autowired UserRepository userRepository;
	@Override
	public void run(String... args) throws Exception {
		User user = new User("Amol","Admin");
		userRepository.save(user);
		userRepository.findAll()
		.stream().forEach(x-> System.out.println(x.getUserName()));
		//using jpa
		System.out.println(userRepository.findByUserNameAndPassword("Amol","Admin"));
		
	}

}
