package com.example.demo.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

@Configuration
@EnableWebSecurity
public class SecureConfigure extends WebSecurityConfigurerAdapter {
	@Autowired
	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		// TODO Auto-generated method stub
		auth.inMemoryAuthentication()
		.withUser("Amol")
		.password("{noop}admin")
		.roles("Admin");
	}

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		
		http.csrf().disable(); //for blocking by default spring login page
		
		 //login page configuration
		 http.formLogin()
		.loginPage("/login")
		.usernameParameter("userName")
		.passwordParameter("password").defaultSuccessUrl("/").failureUrl("/errors");
		
		 //logout page
		 http.logout()
		.logoutUrl("/logout");
		
		//for making secure page means page can not access without login
		
		 http.exceptionHandling().accessDeniedPage("/login");
		 
		 http.authorizeRequests()
		.antMatchers("/login").permitAll() //allow login page to publicly access to all
		.antMatchers("/errors").permitAll()
		.antMatchers("/").authenticated()  // ...require user to at least be authenticated
		.antMatchers("/adminpage").access("hasRole('admin')") // role bases access
		.anyRequest().authenticated(); //all other pages redirect to login
		
	}
	
}
