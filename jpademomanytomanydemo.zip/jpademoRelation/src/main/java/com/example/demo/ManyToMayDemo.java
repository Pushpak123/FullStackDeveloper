package com.example.demo;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

import com.fasterxml.classmate.AnnotationOverrides.StdBuilder;

@Component
public class ManyToMayDemo implements CommandLineRunner {

	@Autowired
	CourseRepository cRepo;

	@Override
	public void run(String... args) throws Exception {

		System.out.println("Many to Many Demo");

		Course courceOne = new Course();
		courceOne.courseName = "Java";

		Course courceTwo = new Course();
		courceOne.courseName = "Angular";

		Student studentOne = new Student();
		studentOne.studentName = "Anil";

		Student studentTwo = new Student();
		studentOne.studentName = "Viral";

		Student studentThree = new Student();
		studentOne.studentName = "Neha";

		courceOne.Students = new ArrayList<Student>();
		courceOne.Students.add(studentOne);
		courceOne.Students.add(studentTwo);
		courceOne.Students.add(studentThree);

		courceTwo.Students = new ArrayList<Student>();
		courceTwo.Students.add(studentOne);

		List<Course> courceList = new ArrayList<>();
		courceList.add(courceOne);
		courceList.add(courceTwo);
		cRepo.saveAll(courceList);
		
		

	}
}

interface CourseRepository extends JpaRepository<Course, Integer> {

}

// child class
@Entity
class Student {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public int studentId;

	public String studentName;

	@ManyToMany(cascade = CascadeType.ALL, mappedBy = "Students")
	List<Course> Courses;
}

// parent class
@Entity
class Course {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public int courseId;

	public String courseName;

	@ManyToMany(cascade = CascadeType.ALL)
	List<Student> Students;
}
