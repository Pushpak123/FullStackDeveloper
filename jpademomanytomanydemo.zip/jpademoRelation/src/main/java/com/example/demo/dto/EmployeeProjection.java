package com.example.demo.dto;

import java.io.Serializable;

import org.springframework.stereotype.Component;

@Component
public class EmployeeProjection implements Serializable {

	private String employeeName;
	
	private int salary;
	
	public EmployeeProjection() {}

	public EmployeeProjection(String employeeName, int salary) {
		super();
		this.employeeName = employeeName;
		this.salary = salary;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}
	
	
	
	
}
