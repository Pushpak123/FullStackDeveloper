package com.example.demo.dto;

import java.io.Serializable;

import org.springframework.stereotype.Component;


public class EmployeeSkillDTO implements Serializable {

	public String employeeName;
	
	public String skillName;

	public EmployeeSkillDTO(String employeeName, String skillName) {
		 
		this.employeeName = employeeName;
		this.skillName = skillName;
	}
	

	
}
