package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;

import com.example.demo.dto.EmployeeProjection;
import com.example.demo.entity.Employee;
import com.example.demo.entity.Skill;

@Component
public interface EmployeeRepository extends JpaRepository<Employee, Integer> {

	@Query("FROM Employee e join fetch e.skill s WHERE e.employeeName=:empName")
	List<Employee> getAllSkillByEmployeeName(@Param("empName") String empName);
	
	@Query(nativeQuery=true,
			value =  "SELECT employee.* FROM Employee ")
	List<Employee> getAllSkillByEmployeeNameUsingSQL(@Param("empName") String empName);

}


//EmployeeID -> employe_id
//ABcdafd  -> A_B_cdafd