package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;

import com.example.demo.dto.EmployeeProjection;
import com.example.demo.dto.EmployeeSkillDTO;
import com.example.demo.entity.Employee;
import com.example.demo.entity.Skill;

@Component
public interface SkillRepository extends JpaRepository<Skill, Integer> {

	//@Query("FROM SKILL S , S.employee e WHERE e.EmployeeName=:empName")
	
	@Query("FROM Skill S join fetch S.employee e WHERE e.employeeName=:empName")	
	List<Skill> getAllSkillByEmployeeName(@Param("empName") String empName);
	
	@Query("select "
			+ "new com.example.demo.dto.EmployeeSkillDTO"
			+ "(e.employeeName,S.skillName) "
			+ "FROM Skill S , Employee e ")
	List<EmployeeSkillDTO> getEmpDetail();
	
}
